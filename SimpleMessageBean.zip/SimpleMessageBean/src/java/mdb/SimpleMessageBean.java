/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/MessageDrivenBean.java to edit this template
 */
package mdb;


import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
@MessageDriven(activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "jms/Queue"),
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue")
})
public class SimpleMessageBean implements MessageListener {
    
//    static final Logger logger = Logger.getLogger("SimpleMessageBean");
//    ArrayList<String> textmess = new ArrayList<String>();
//    
//    @Resource
//    private MessageDrivenContext mdc;
//    
//    public SimpleMessageBean() {
//    }
//    
//    @Override
//    public void onMessage(Message inMessage) {
//        
//        TextMessage msg = null;
//        try {
//        if (inMessage instanceof TextMessage) {
//        msg = (TextMessage) inMessage;
//        textmess.add(msg.getText());
//        
//        logger.info("MESSAGE BEAN: Message received: " + msg.getText());
//        
//        System.out.println(textmess.size());
//        
//        
//        int[] num = new int[10];
//        int i = 0;
//        for(String a: textmess) {
//            
//            String[] word = a.split(" ");
//            num[i] = Integer.parseInt(word[1]);
//            System.out.println(num[i]);
//            i++;
//        }
//        
//       
//        Arrays.sort(num);
//        
////        System.out.println("\nОтсортированные числа: ");
////        for (int n: num){
////            System.out.print(n + " ");
////        }
//        
//        try (FileWriter fileWriter = new FileWriter("D:\\документы\\БГУИР\\Маша\\6 сем\\РИС\\lr\\lr4\\example.txt", true)) {
//            for (int elem : num) { // Перебираем элементы массива
//                fileWriter.append(String.valueOf(elem)) // Записываем элементы в файл, приводим целые числа к строковому формату
//                    .append(" "); // Добавляем пробелы между элементами
//                fileWriter.flush(); // Очищаем буфер потока
//    }
//}       catch (IOException ex) {
//            Logger.getLogger(SimpleMessageBean.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        
//        } else {
//        logger.warning("Message of wrong type: " + inMessage.getClass().getName());
//        }
//        } catch (JMSException e) {
//        e.printStackTrace();
//        mdc.setRollbackOnly();
//        } catch (Throwable te) {
//        te.printStackTrace();
//        }
//             
//    }
    
    private static final Logger logger = Logger.getLogger("SimpleMessageBean");
    private ArrayList<Integer> numbersList = new ArrayList<>();

    @Resource
    private MessageDrivenContext mdc;

    public SimpleMessageBean() {
    }

    @Override
    public void onMessage(Message inMessage) {
        TextMessage msg = null;
        try {
            if (inMessage instanceof TextMessage) {
                msg = (TextMessage) inMessage;
                numbersList.add(Integer.valueOf(msg.getText()));

                logger.info("MESSAGE BEAN: Message received: " + msg.getText());

                if (numbersList.size() >= 10) {
                    Integer[] numbersArray = numbersList.toArray(new Integer[0]);
                    Arrays.sort(numbersArray);

                    try (FileWriter fileWriter = new FileWriter("D:\\документы\\БГУИР\\Маша\\6 сем\\РИС\\lr\\lr4\\example.txt", true)) {
                        for (Integer num : numbersArray) {
                            fileWriter.write(num.toString() + " ");
                        }
                        fileWriter.flush();
                    } catch (IOException ex) {
                        logger.log(Level.SEVERE, null, ex);
                    }
                }
            } else {
                logger.warning("Message of wrong type: " + inMessage.getClass().getName());
            }
        } catch (JMSException e) {
            e.printStackTrace();
            mdc.setRollbackOnly();
        } catch (Throwable te) {
            te.printStackTrace();
        }
    }
}
    
    
